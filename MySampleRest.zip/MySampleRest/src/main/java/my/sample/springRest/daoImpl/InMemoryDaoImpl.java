package my.sample.springRest.daoImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import my.sample.springRest.bean.Employee;
import my.sample.springRest.dao.EmployeeDao;


@Repository
public class InMemoryDaoImpl implements EmployeeDao {

	
	@Autowired 
	NamedParameterJdbcTemplate jdbcTemplate;

	   
	   public List<Employee> getAllEmployees() {
		   
		   return jdbcTemplate.query("SELECT * FROM employee", 
				      (ResultSet rs, int rowNum) -> {
				        Employee emp = new Employee();
				        emp.setId(rs.getInt("id"));
				        emp.setName(rs.getString("name"));
				        emp.setAge(rs.getInt("age"));
				        
				        return emp;
				    });	   
		   
	   }
	   
	   public String getStorageType()
	   {
		   return "h2";
	   }
}
