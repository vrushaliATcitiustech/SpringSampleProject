-- data.sql
INSERT INTO employee(id, name, age) 
VALUES (100, 'vrush', 20);
INSERT INTO employee(id, name, age) 
VALUES ('200', 'nik', 22);
