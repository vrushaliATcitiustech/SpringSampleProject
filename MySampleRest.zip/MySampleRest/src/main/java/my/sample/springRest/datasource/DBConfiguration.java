package my.sample.springRest.datasource;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import my.sample.springRest.dao.EmployeeDao;
import my.sample.springRest.daoImpl.FileStoreDaoImpl;
import my.sample.springRest.daoImpl.InMemoryDaoImpl;

@Configuration
public class DBConfiguration {
	
	String storage = "h2"; //"h2"

	 @Bean
	  public DataSource dataSource() {
	    return new EmbeddedDatabaseBuilder()
	      .generateUniqueName(false)
	      .setName("testdb")
	      .setType(EmbeddedDatabaseType.H2)
	      .addDefaultScripts()
	      .setScriptEncoding("UTF-8")
	      .ignoreFailedDrops(true)
	      .build();
	  }

	  @Bean
	  public NamedParameterJdbcTemplate namedParamJdbcTemplate() {
	    NamedParameterJdbcTemplate namedParamJdbcTemplate = 
	      new NamedParameterJdbcTemplate(dataSource());
	    return namedParamJdbcTemplate;
	  }
	  
	  @Bean
	  public EmployeeDao empDao() {
	   if ("h2".equalsIgnoreCase(storage)) {
	    return new InMemoryDaoImpl();
	   }

	   else  {
		    return new FileStoreDaoImpl();
		   }
	  }
	
}
