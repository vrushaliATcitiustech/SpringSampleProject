package my.sample.springRest.controller;

import java.util.List;
import my.sample.springRest.bean.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import my.sample.springRest.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService empService;
	
	//Get All Employees
	
	@RequestMapping(value = "/employees", method = RequestMethod.GET, headers = "Accept=application/json")	
	public List<Employee> getAllEmployees()
	{
		List<Employee> ListOfAllEmp = empService.getAllEmployees(); 
		return ListOfAllEmp;
	}
	
	
	/* Below APIs not in use */
	
/*	//Get Employee by id
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public Employee getEmployee(@PathVariable("id") int id)
	{
		return empService.getEmployee(id);
	}
	
	//Update an employee
	@RequestMapping(value = "/employees", method = RequestMethod.PUT, headers = "Accept=application/json")
	public Employee updateEmployee(@RequestBody Employee e)
	{
		return empService.updateEmployee(e);
	}
	
	//Add new Employee
	
	@RequestMapping(value = "/employees", method = RequestMethod.POST, headers = "Accept=application/json")
	public Employee addEmployee(@RequestBody Employee e)
	{
		return empService.addEmployee(e);
	}
	
	//Delete an employee
	
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public void deleteEmployee( @PathVariable("id") int id)
	{
		empService.deleteEmployee(id);
	}
	
	//For File storage
	
	//JSON Write to file
	@RequestMapping(value = "/jsonWrite", method = RequestMethod.POST, headers = "Accept=application/json")
	public void jsonFilewrite(@RequestBody  Employee e)
	{
		empService.writeJson(e);
	}
	
	//Read JSON from File
	@RequestMapping(value = "/jsonFetch", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Employee> jsonFileFetch()
	{
		List<Employee> listOfEmployees = empService.fetchJson();
		return listOfEmployees;
		
	}

	*/

}
