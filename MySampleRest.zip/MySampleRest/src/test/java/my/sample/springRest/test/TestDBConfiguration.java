package my.sample.springRest.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import my.sample.springRest.dao.EmployeeDao;
import my.sample.springRest.datasource.DBConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DBConfiguration.class, loader = AnnotationConfigContextLoader.class)
public class TestDBConfiguration {

	
	@Autowired
	EmployeeDao employeeDao;
	
	String storage = "h2";
	
	@Test
	public void testEmployeeDao()
	{
		if("h2".equalsIgnoreCase(storage))
		assertEquals( "class my.sample.springRest.daoImpl.InMemoryDaoImpl", this.employeeDao.getClass().toString());
		else 
		assertEquals( "class my.sample.springRest.daoImpl.FileStoreDaoImpl", this.employeeDao.getClass().toString());
			
	}
	
	

}
