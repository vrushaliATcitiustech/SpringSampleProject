package my.sample.springRest.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import my.sample.springRest.bean.Employee;
import my.sample.springRest.dao.EmployeeDao;

@Repository
public class EmployeeService {
	
	
	@Autowired
	EmployeeDao empDao;
	
	

	//Get all employees either from file storage or from in memory database
	
	public List<Employee> getAllEmployees()
	{
		
			return empDao.getAllEmployees();
		
	
	}
	
	/* Don't check - Incomplete code below*/
	
	/*public List<Employee> getAllEmployees()
	{
		
		List<Employee> employees = new ArrayList<Employee>(empMap.values());
		return employees;
	}*/
	
	/*//Get an employee on id
	public Employee getEmployee(int id)
	{
		return empMap.get(id);
	}
	
	//Update an employee with given id
	public Employee updateEmployee(Employee e)
	{
		if(e.getId()<=0)
			return null;
		empMap.put(e.getId(), e);
		return e;
	}
	
	//Add a new employee
	public Employee addEmployee(Employee e)
	{
		e.setId(getMaxID()+1);
	    empMap.put(e.getId(), e);
		return e;
	}
	
	//Delete an existing employee
	public void deleteEmployee(int id)
	{
		empMap.remove(id); 
	}
	
	
	//Write employee details to file	
	@SuppressWarnings("unchecked")
	public void writeJson(Employee emp)

	 {
		JSONObject employeeDetails = new JSONObject();
        employeeDetails.put("id", emp.getId());
        employeeDetails.put("name", emp.getName());
        employeeDetails.put("age", emp.getAge() );
         
        JSONObject employeeObject = new JSONObject();
        employeeObject.put("employee", employeeDetails);
        
        //Write JSON Object into JSON array
        JSONArray employeeList = new JSONArray();
        employeeList.add(employeeObject);
        
        //Write file
        
		 try {
				 File file = new File("/Users/vrushaliP2/Documents/EmployeeDetails.json");
				
				 FileWriter fw;
				 if(!file.exists())
				 {
					 fw = new FileWriter(file,false);
					 
					 
				 }
				 else
				 {
					 fw = new FileWriter(file,true);
					 
				 }
				
				fw.write(employeeList.toJSONString());
				fw.flush();
				fw.close();
				System.out.println("Successfully Copied JSON Object to File...");
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
	
	//Read employee details from file
	
	@SuppressWarnings("finally")
	public List<Employee> fetchJson()
	 {
		 
		//JSON parser object to parse read file
	        JSONParser jsonParser = new JSONParser();
	        List<Employee> empList = new ArrayList<Employee>();
	         
	        try (FileReader reader = new FileReader("/Users/vrushaliP2/Documents/EmployeeDetails.json"))
	        {
	            //Read JSON file
	            Object obj = jsonParser.parse(reader);
	 
	            JSONArray employeeList = (JSONArray) obj;
	            System.out.println(employeeList);
	             
	            //Iterate over employee array
	            
	           
	            for(Object emp : employeeList)
	            {
	            	
	            	empList.add(parseEmployeeObject( (JSONObject) emp ));
	            }
	           // employeeList.forEach( emp -> parseEmployeeObject( (JSONObject) emp ) );
	            return empList;
	 
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (org.json.simple.parser.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        finally
	        {
	        	return empList;
	        }
		 
	       
	       */
		 


	/*private Employee parseEmployeeObject(JSONObject emp) {
		// TODO Auto-generated method stub
		
		JSONObject employeeObj = (JSONObject)emp.get("employee");
		
		int id = (int)(long)employeeObj.get("id");
				String name= (String)employeeObj.get("name");
				int age = (int)(long)employeeObj.get("age");
				
		Employee newEmp = new Employee(id, name, age);
		return newEmp;
		
		
		
		
	}

	public static HashMap<Integer, Employee> getEmpMap()
	{
		return empMap;
	}
	
	public static Integer getMaxID()
	{
		Integer maxID = 0;
		
		for (Integer i :empMap.keySet())
		{
			if (i >= maxID)
			{
				maxID = i;
			}
		}
		return maxID;
	}*/

}
