package my.sample.springRest.daoImpl;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Repository;

import my.sample.springRest.bean.Employee;
import my.sample.springRest.dao.EmployeeDao;

@Repository
public class FileStoreDaoImpl implements EmployeeDao {

	
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		JSONParser jsonParser = new JSONParser();
        List<Employee> empList = new ArrayList<Employee>();
         
        try (FileReader reader = new FileReader("/Users/vrushaliP2/Documents/EmployeeDetails.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);
 
            JSONArray employeeList = (JSONArray) obj;
            System.out.println(employeeList);
             
            //Iterate over employee array
            
           
            for(Object emp : employeeList)
            {
            	
            	empList.add(parseEmployeeObject( (JSONObject) emp ));
            }
           // employeeList.forEach( emp -> parseEmployeeObject( (JSONObject) emp ) );
            return empList;
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        finally
        {
        	return empList;
        }
	 
         
	}
	
	private Employee parseEmployeeObject(JSONObject emp) {
		// TODO Auto-generated method stub
		
		JSONObject employeeObj = (JSONObject)emp.get("employee");
		
		int id = (int)(long)employeeObj.get("id");
				String name= (String)employeeObj.get("name");
				int age = (int)(long)employeeObj.get("age");
				
		Employee newEmp = new Employee(id, name, age);
		return newEmp;
		
		
		
		
	}
	
	public String getStorageType()
	   {
		   return "file";
	   }

}
