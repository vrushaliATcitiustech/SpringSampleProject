-- schema.sql
DROP TABLE IF EXISTS employee;

CREATE TABLE employee(
  id NUMERIC IDENTITY PRIMARY KEY,
  name VARCHAR(512) NOT NULL,
  age NUMERIC NOT NULL
);

