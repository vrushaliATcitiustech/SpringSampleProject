package my.sample.dryrun;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import my.sample.springRest.bean.Employee;

public class RunMe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(System.getProperty("os"));
		
		/*JSONParser jsonParser = new JSONParser();
        List<Employee> empList = new ArrayList<Employee>();
         
        try (FileReader reader = new FileReader("/Users/vrushaliP2/Documents/EmployeeDetails.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);
 
            JSONArray employeeList = (JSONArray) obj;
            System.out.println(employeeList);
             
            //Iterate over employee array
            
           
            for(Object emp : employeeList)
            {
            	
            	System.out.println(parseEmployeeObject( (JSONObject) emp ).toString());
            	empList.add(parseEmployeeObject( (JSONObject) emp ));
            	
            }
           // employeeList.forEach( emp -> parseEmployeeObject( (JSONObject) emp ) );
            
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	 */
         
     
 }
	 


public static Employee parseEmployeeObject(JSONObject emp) {
	// TODO Auto-generated method stub
	
	JSONObject employeeObj = (JSONObject)emp.get("employee");
	//if (!employeeObj.isEmpty())

	
	int id = (int)(long)employeeObj.get("id");
	//int id = Integer.parseInt((String)employeeObj.get("id"));
			String name= (String)employeeObj.get("name");
			int age = (int)(long)employeeObj.get("age");
			//int age=Integer.parseInt((String)employeeObj.get("age"));
	Employee newEmp = new Employee(id, name, age);
	return newEmp;
	
	
	
}


	}


