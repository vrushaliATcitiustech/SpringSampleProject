package my.sample.springRest.dao;

import java.util.List;

import my.sample.springRest.bean.Employee;

public interface EmployeeDao {
	
	public List<Employee> getAllEmployees();
	
	

}
